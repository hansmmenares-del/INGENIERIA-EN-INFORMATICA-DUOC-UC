Proceso orden_menor_a_mayor
	Definir A, B, C como Enteros;
	
	Repetir
		
		Escribir "Ingresa el primer numero: ";
		Leer A;
		
		
		Si A <= 0 Entonces
			Escribir "A, B y C deben ser numeros positivos";
			Escribir "Porfavor vuelve a ingresar el valor de A...";
		FinSi
		
	Hasta Que A >= 0
	
	
	Repetir
		
		Escribir "Ingresa el segundo numero: ";
		Leer B;
		
		Si B = A Entonces
			Escribir "Los numeros ingresados no pueden ser iguales...";
		FinSi
		
		Si B <= 0 Entonces
			Escribir "A, B y C deben ser numeros positivos";
			Escribir "Porfavor vuelve a ingresar el valor de B";
		FinSi
		
	Hasta Que B <> A y B >= 0
	
	
	Repetir
		
		Escribir "Ingresa el tercer numero: ";
		Leer C;
		Si C=A o C=B Entonces
			Escribir "Los numeros ingresados no pueden ser iguales...";
		FinSi
		Si C <= 0 Entonces
			Escribir "A, B y C deben ser numeros positivos";
			Escribir "Porfavor vuelve a ingresar el valor de C";
		FinSi
		
	Hasta Que C<>A y C<>B y C >= 0
	
	
	Si A > B y A > C y B > C Entonces
		Escribir "El orden de los numeros de menor a mayor es: ", C, " < ", B, " < ", A;
	FinSi
	SI A > C y A > B y C > B Entonces
		Escribir "El orden de los numeros de menor a mayor es: ", B, " < ", C, " < ", A;
	FinSi
	Si B > A y B > C y A > C Entonces
		Escribir "El orden de los numeros de menor a mayor es: ", C, " < ", A, " < ", B;
	FinSi
	Si B > C y B > A y C > A Entonces
		Escribir "El orden de los numeros de menor a mayor es: ", A, " < ", C, " < ", B;
	FinSi
	SI C > A y C > B y A > B Entonces
		Escribir "El orden de los numeros de menor a mayor es: ", B, " < ", A, " < ", C;
	FinSi
	Si C > B y C > A y B > A Entonces
		Escribir "El orden de los numeros de menor a mayor es: ", A, " < ", B, " < ", C;
	FinSi
	
FinProceso
